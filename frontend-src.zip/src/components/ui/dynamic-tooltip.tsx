'use client'

import { useState, useRef, useEffect, ReactNode } from 'react'
import { cn } from '@/utils'

type DynamicTooltipProps = {
  title?: string
  content: string | ReactNode
  className?: string
}

export function DynamicTooltip({ title, content, className }: DynamicTooltipProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [position, setPosition] = useState<'top' | 'bottom'>('top')
  const triggerRef = useRef<HTMLDivElement>(null)

  const updatePosition = () => {
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect()
      if (rect.top < 150) {
        setPosition('bottom')
      } else {
        setPosition('top')
      }
    }
  }

  // Listens to scroll and resize events globally when the tooltip is open
  useEffect(() => {
    if (isVisible) {
      updatePosition()
      window.addEventListener('scroll', updatePosition, true)
      window.addEventListener('resize', updatePosition)
      
      return () => {
        window.removeEventListener('scroll', updatePosition, true)
        window.removeEventListener('resize', updatePosition)
      }
    }
  }, [isVisible])

  return (
    <div
      className="relative inline-flex items-center"
      onMouseLeave={() => setIsVisible(false)}
    >
      {/* Trigger: Reduced Question Mark Icon */}
      <div
        ref={triggerRef}
        onMouseEnter={() => setIsVisible(true)}
        className="cursor-help flex items-center justify-center"
      >
        {/* Changed width/height from 24 to 16. Fixed React casing on fillRule/clipRule */}
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" clipRule="evenodd" d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM12 7.75C11.3787 7.75 10.875 8.25368 10.875 8.875C10.875 9.28921 10.5392 9.625 10.125 9.625C9.71079 9.625 9.375 9.28921 9.375 8.875C9.375 7.42525 10.5503 6.25 12 6.25C13.4497 6.25 14.625 7.42525 14.625 8.875C14.625 9.58584 14.3415 10.232 13.883 10.704C13.7907 10.7989 13.7027 10.8869 13.6187 10.9708C13.4029 11.1864 13.2138 11.3753 13.0479 11.5885C12.8289 11.8699 12.75 12.0768 12.75 12.25V13C12.75 13.4142 12.4142 13.75 12 13.75C11.5858 13.75 11.25 13.4142 11.25 13V12.25C11.25 11.5948 11.555 11.0644 11.8642 10.6672C12.0929 10.3733 12.3804 10.0863 12.6138 9.85346C12.6842 9.78321 12.7496 9.71789 12.807 9.65877C13.0046 9.45543 13.125 9.18004 13.125 8.875C13.125 8.25368 12.6213 7.75 12 7.75ZM12 17C12.5523 17 13 16.5523 13 16C13 15.4477 12.5523 15 12 15C11.4477 15 11 15.4477 11 16C11 16.5523 11.4477 17 12 17Z" fill="#2D9CDB"/>
        </svg>
      </div>

      {/* Reduced Tooltip Content Card */}
      <div
        className={cn(
          "absolute z-50 p-4 w-[229px] rounded-xl border border-gray-50 bg-white shadow-sm transition-all duration-300 ease-out",
          position === 'top'
            ? "bottom-full mb-2 left-1/2 -translate-x-2/5 origin-bottom"
            : "top-full mt-2 left-1/2 -translate-x-2/5 origin-top",
          isVisible 
            ? "opacity-100 scale-100 visible" 
            : "opacity-0 scale-95 invisible pointer-events-none",
          className
        )}
      >
        {title && (
          <h4 className="mb-1.5 font-poppins text-body-xxs leading-4 font-medium text-info-500">
            {title}
          </h4>
        )}
        
        <p className="font-poppins font-normal text-body-xxs text-body leading-4 tracking-wide">
          {content}
        </p>
      </div>
    </div>
  )
}