// Full replacement for the existing stub.
// Every hook follows the same pattern as use-auth-mutations.ts:
//   useMutation → service call → cache invalidation → toast feedback

import {
  useQuery,
  useMutation,
  useInfiniteQuery,
  useQueryClient,
  type InfiniteData,
} from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import { artworkService } from '@/services/artwork.service'
import { useArtworkStore } from '@/store/artwork.store'
import { useToast } from '@/components/ui/toaster'
import { QUERY_KEYS, STALE_TIMES } from '@/constants'
import type {
  Artwork,
  ArtworkFilters,
  CreateArtworkPayload,
  UpdateArtworkPayload,
  PaginatedArtworksResponse,
  ListingType,
} from '@/types/artwork'

// ── Query key helpers ─────────────────────────────────────────────────────────
// Extend the existing QUERY_KEYS from constants/index.ts

const ART_KEYS = {
  all:       ['artworks'] as const,
  lists:     () => [...ART_KEYS.all, 'list'] as const,
  list:      (f: ArtworkFilters) => [...ART_KEYS.lists(), f] as const,
  feed:      (p: object) => [...ART_KEYS.all, 'feed', p] as const,
  detail:    () => [...ART_KEYS.all, 'detail'] as const,
  byId:      (id: string) => [...ART_KEYS.detail(), id] as const,
  bySlug:    (slug: string) => [...ART_KEYS.all, 'slug', slug] as const,
  myDrafts:  () => [...ART_KEYS.all, 'my-drafts'] as const,
}

// ── Reads ─────────────────────────────────────────────────────────────────────

export function useArtwork(id: string) {
  return useQuery({
    queryKey:  ART_KEYS.byId(id),
    queryFn:   () => artworkService.getById(id).then((r) => r.data),
    staleTime: STALE_TIMES.medium,
    enabled:   Boolean(id),
  })
}

export function useArtworkBySlug(slug: string, enabled = true) {
  return useQuery({
    queryKey:  ART_KEYS.bySlug(slug),
    queryFn:   () => artworkService.getBySlug(encodeURIComponent(slug)).then((r) => r.data),
    staleTime: STALE_TIMES.medium,
    enabled:   enabled && Boolean(slug),
  })
}

export function useArtworkList(filters: ArtworkFilters = {}) {
  return useQuery({
    queryKey:  ART_KEYS.list(filters),
    queryFn:   () => artworkService.list(filters),
    staleTime: STALE_TIMES.fast,
  })
}

// Infinite scroll feed — used by FeedSection and discover pages
export function useFeed(
  params: {
    categories?: string[]
    // location?: string
    country?: string
    state?: string
    city?: string
    size_label?: string
    sort?: 'for_you' | 'following' | 'new' | 'trending' | 'newbies'
  } = {},
) {
  return useInfiniteQuery<PaginatedArtworksResponse>({
    queryKey: ART_KEYS.feed(params),
    queryFn: ({ pageParam = 1 }) =>
      artworkService.getFeed({ page: pageParam as number, perPage: 12, ...params }),
    getNextPageParam: (last) => last.has_next ? last.page + 1 : undefined,
    initialPageParam: 1,
    staleTime: STALE_TIMES.fast,
  })
}

export function useHeroArtworks(limit = 5) {
  return useQuery({
    queryKey: QUERY_KEYS.artworks({ featured: true, limit }),
    queryFn: () => artworkService.getFeatured(limit).then((r) => r.data),
    staleTime: STALE_TIMES.slow,
    retry: 1,
  })
}

// "Top Picks by Artsony" — real ranking algorithm (decayed hot-score, one
// per creator), not manual curation. See get_top_picks() migration.
export function useTopPicks(period: 'all' | 'week' = 'all', limit = 8, listingType?: ListingType) {
  return useQuery({
    queryKey: ['artworks', 'top-picks', period, limit, listingType ?? 'ALL'],
    queryFn: () => artworkService.getTopPicks(limit, period, listingType).then((r) => r.data),
    staleTime: STALE_TIMES.medium,
  })
}

// "Trending regardless of upload date" — see artworkService.getTrending.
// Use this (not useTopPicks('week')) for "what's hot right now" surfaces
// like Gallery Pulse, where an older artwork picking up a burst of likes
// this week should still qualify.
export function useTrendingArtworks(limit = 8, windowDays = 7, listingType?: ListingType) {
  return useQuery({
    queryKey: ['artworks', 'trending', windowDays, limit, listingType ?? 'ALL'],
    queryFn: () => artworkService.getTrending(limit, windowDays, listingType).then((r) => r.data),
    staleTime: STALE_TIMES.medium,
  })
}

export function useViewArtwork() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => artworkService.view(id),

    onSuccess: (_data, id) => {
      // Refresh this artwork in cache
      queryClient.invalidateQueries({
        queryKey: ART_KEYS.byId(id),
      })
    },
  })
}

// Other published artworks by a given creator — powers the ArtCard hover
// profile's "recent artworks" strip. Lazy: pass `enabled` so it only fires
// once the hover card is actually shown, not for every card mounted in a grid.
export function useCreatorArtworks(creatorId: string, enabled: boolean) {
  return useQuery({
    queryKey: ['artworks', 'by-creator', creatorId],
    queryFn: () =>
      artworkService.list({
        creator_id: creatorId,
        status: 'PUBLISHED',
        visibility: 'PUBLIC',
        sort_by: 'created_at',
        sort_order: 'desc',
        limit: 4,
      }),
    enabled: enabled && Boolean(creatorId),
    staleTime: STALE_TIMES.medium,
  })
}

export function useArtworkLocations(
  level: 'country' | 'state' | 'city',
  parent?: { country?: string; state?: string },
) {
  return useQuery({
    queryKey: ['artworks', 'locations', level, parent?.country ?? null, parent?.state ?? null],
    queryFn: () => artworkService.getLocations(level, parent).then((r) => r.data),
    staleTime: STALE_TIMES.slow,
    // state/city queries are meaningless without a parent country selected
    // for state, or country+state for city — keep them idle until then
    // rather than firing a request that'll just return an empty list.
    enabled: level === 'country' || Boolean(parent?.country),
  })
}

export function useMarketplaceArtworks(limit = 10) {
  return useQuery({
    queryKey: ['artworks', 'marketplace-shop', limit],
    queryFn: () =>
      artworkService.list({
        listing_type: 'MARKETPLACE',
        status: 'PUBLISHED',
        visibility: 'PUBLIC',
        sort_by: 'created_at',
        sort_order: 'desc',
        limit,
      }),
    staleTime: STALE_TIMES.fast,
  })
}

// Distinct SIZE-variant labels across all published artworks — populates
// the "Medium" filter with real, currently-available sizes rather than a
// hardcoded guess.
export function useSizeLabels() {
  return useQuery({
    queryKey: ['artworks', 'size-labels'],
    queryFn: () => artworkService.getSizeLabels(),
    staleTime: STALE_TIMES.slow,
  })
}

// Artist's own artworks (profile page — includes drafts when authed)
export function useMyArtworks(filters: Omit<ArtworkFilters, 'creator_id'> = {}) {
  return useQuery({
    queryKey:  ART_KEYS.myDrafts(),
    queryFn:   () => artworkService.list({ ...filters }),
    staleTime: STALE_TIMES.medium,
  })
}

export function useSearchArtworks(query: string, filters?: ArtworkFilters) {
  return useQuery({
    queryKey:  [...ART_KEYS.lists(), 'search', query, filters],
    queryFn:   () => artworkService.search(query, filters),
    enabled:   query.length >= 2,
    staleTime: STALE_TIMES.medium,
  })
}

// Shop page (browse + search-results mode) — paginated, works with an empty
// query too, since browse mode reuses the same grid/filters as search mode.
const RESULTS_PAGE_SIZE = 12

export function useInfiniteArtworkResults(filters: ArtworkFilters) {
  return useInfiniteQuery({
    queryKey: [...ART_KEYS.lists(), 'shop-results', filters],
    queryFn: ({ pageParam }) =>
      artworkService.list({ ...filters, page: pageParam, limit: RESULTS_PAGE_SIZE }),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => (lastPage.has_next ? lastPage.page + 1 : undefined),
    staleTime: STALE_TIMES.medium,
  })
}

// ── Create ────────────────────────────────────────────────────────────────────

export function useCreateArtwork() {
  const qc = useQueryClient()
  const router = useRouter()
  const clearDraft = useArtworkStore((s) => s.clearDraft)
  const { success, error } = useToast()

  return useMutation({
    mutationFn: (payload: CreateArtworkPayload) => artworkService.create(payload),

    onSuccess: ({ data }) => {
      qc.invalidateQueries({ queryKey: ART_KEYS.lists() })
      qc.setQueryData(ART_KEYS.byId(data.id), data)
      clearDraft()
      success('Artwork created', `"${data.title}" was saved as a draft.`)
      router.push(`/artwork/${data.id}/edit`)
    },

    onError: () => {
      error('Upload failed', 'Could not save your artwork. Please try again.')
    },
  })
}

// ── Update ────────────────────────────────────────────────────────────────────

export function useUpdateArtwork(id: string) {
  const qc = useQueryClient()
  const { success, error } = useToast()

  return useMutation({
    mutationFn: (payload: UpdateArtworkPayload) => artworkService.update(id, payload),

    onMutate: async (payload) => {
      await qc.cancelQueries({ queryKey: ART_KEYS.byId(id) })
      const prev = qc.getQueryData<Artwork>(ART_KEYS.byId(id))
      
      // FIX: Cast the optimistically merged object as Artwork to satisfy the cache type
      qc.setQueryData<Artwork>(ART_KEYS.byId(id), (old) =>
        old ? ({ ...old, ...payload } as Artwork) : old,
      )
      
      return { prev }
    },

    onSuccess: ({ data }) => {
      qc.setQueryData(ART_KEYS.byId(id), data)
      qc.invalidateQueries({ queryKey: ART_KEYS.lists() })
      success('Saved', 'Your changes have been saved.')
    },

    onError: (_err, _payload, ctx) => {
      if (ctx?.prev) qc.setQueryData(ART_KEYS.byId(id), ctx.prev)
      error('Save failed', 'Could not save your changes. Please try again.')
    },
  })
}

// ── Publish ───────────────────────────────────────────────────────────────────

export function usePublishArtwork() {
  const qc = useQueryClient()
  const { success, error } = useToast()

  return useMutation({
    mutationFn: (id: string) => artworkService.publish(id),

    onSuccess: ({ data }) => {
      qc.setQueryData(ART_KEYS.byId(data.id), data)
      qc.invalidateQueries({ queryKey: ART_KEYS.lists() })
      success('Published!', `"${data.title}" is now live.`)
    },

    onError: () => {
      error('Publish failed', 'Could not publish your artwork. Please try again.')
    },
  })
}

// ── Archive ───────────────────────────────────────────────────────────────────

export function useArchiveArtwork() {
  const qc = useQueryClient()
  const { success, error } = useToast()

  return useMutation({
    mutationFn: (id: string) => artworkService.archive(id),

    onSuccess: ({ data }) => {
      qc.setQueryData(ART_KEYS.byId(data.id), data)
      qc.invalidateQueries({ queryKey: ART_KEYS.lists() })
      success('Archived', `"${data.title}" has been archived.`)
    },

    onError: () => {
      error('Archive failed', 'Could not archive this artwork.')
    },
  })
}

// ── Delete ────────────────────────────────────────────────────────────────────

export function useDeleteArtwork() {
  const qc     = useQueryClient()
  const router = useRouter()
  const { success, error } = useToast()

  return useMutation({
    mutationFn: (id: string) => artworkService.delete(id),

    onSuccess: (_data, id) => {
      qc.removeQueries({ queryKey: ART_KEYS.byId(id) })
      qc.invalidateQueries({ queryKey: ART_KEYS.lists() })
      success('Deleted', 'Artwork has been removed.')
      router.push('/profile')
    },

    onError: () => {
      error('Delete failed', 'Could not delete this artwork. Please try again.')
    },
  })
}

// ── Like (with optimistic update) ─────────────────────────────────────────────

export function useLikeArtwork() {
  const qc = useQueryClient()
  const setOptimisticLike = useArtworkStore((s) => s.setOptimisticLike)
  const { error } = useToast()

  // toggle_artwork_like flips whatever the server currently has on file —
  // the `isLiked` passed in is only this client's guess of current state
  // (used for the optimistic flip), never trusted as the true direction.
  // onSuccess reconciles both caches with the server's actual result.
  return useMutation({
    mutationFn: ({ id }: { id: string; isLiked: boolean }) => artworkService.toggleLike(id),

    onMutate: async ({ id, isLiked }) => {
      await qc.cancelQueries({ queryKey: ART_KEYS.byId(id) })
      const prev = qc.getQueryData<Artwork>(ART_KEYS.byId(id))

      setOptimisticLike(id, !isLiked)

      qc.setQueryData<Artwork>(ART_KEYS.byId(id), (old) =>
        old
          ? {
              ...old,
              is_liked: !isLiked,
              like_count: isLiked ? old.like_count - 1 : old.like_count + 1,
            }
          : old,
      )

      // Also update the artwork inside any cached infinite feed pages
      qc.setQueriesData<InfiniteData<PaginatedArtworksResponse>>(
        { queryKey: ART_KEYS.all },
        (old) => {
          if (!old) return old
          return {
            ...old,
            pages: old.pages.map((page) => ({
              ...page,
              data: page.data.map((a) =>
                a.id === id
                  ? { ...a, is_liked: !isLiked, like_count: isLiked ? a.like_count - 1 : a.like_count + 1 }
                  : a,
              ),
            })),
          }
        },
      )

      return { prev }
    },

    onSuccess: ({ data }, { id }) => {
      // Reconcile with the server's actual resulting state — the optimistic
      // flip above was a guess; this is truth, and may differ from the
      // guess if this client's `isLiked` was stale.
      setOptimisticLike(id, data.liked)
      qc.setQueryData<Artwork>(ART_KEYS.byId(id), (old) =>
        old ? { ...old, is_liked: data.liked, like_count: data.like_count } : old,
      )
      qc.setQueriesData<InfiniteData<PaginatedArtworksResponse>>(
        { queryKey: ART_KEYS.all },
        (old) => {
          if (!old) return old
          return {
            ...old,
            pages: old.pages.map((page) => ({
              ...page,
              data: page.data.map((a) =>
                a.id === id ? { ...a, is_liked: data.liked, like_count: data.like_count } : a,
              ),
            })),
          }
        },
      )
    },

    onError: (_err, { id }, ctx) => {
      if (ctx?.prev) qc.setQueryData(ART_KEYS.byId(id), ctx.prev)
      setOptimisticLike(id, ctx?.prev?.is_liked ?? false)
      error('Action failed', 'Could not update like. Please try again.')
    },

    onSettled: (_data, _err, { id }) => {
      // Re-fetch to get authoritative server count
      void qc.invalidateQueries({ queryKey: ART_KEYS.byId(id) })
    },
  })
}

// ── Save / Unsave (with optimistic update) ────────────────────────────────────

export function useSaveArtwork() {
  const qc = useQueryClient()
  // const setOptimisticSave = useArtworkStore((s) => s.setOptimisticSave)
  const { error } = useToast()

  return useMutation({
    // mutationFn: ({ id, isSaved }: { id: string; isSaved: boolean }) =>
    //   isSaved ? artworkService.unsave(id) : artworkService.save(id),

    // onMutate: ({ id, isSaved }) => {
    //   setOptimisticSave(id, !isSaved)
    // },

    // onError: (_err, { id, isSaved }) => {
    //   setOptimisticSave(id, isSaved)
    //   error('Action failed', 'Could not update saved status.')
    // },

    // onSettled: (_data, _err, { id }) => {
    //   void qc.invalidateQueries({ queryKey: ART_KEYS.byId(id) })
    // },

    mutationFn: (id: string) => artworkService.toggleSave(id),

    onMutate: async (id) => {
      await qc.cancelQueries({ queryKey: ART_KEYS.byId(id) })
      const prev = qc.getQueryData<Artwork>(ART_KEYS.byId(id))
      qc.setQueryData<Artwork>(ART_KEYS.byId(id), (old) =>
        old ? { ...old, is_saved: !old.is_saved } : old,
      )
      return { prev, id }
    },

    onError: (_err, id, ctx) => {
      if (ctx?.prev) qc.setQueryData(ART_KEYS.byId(id), ctx.prev)
      error('Action failed', 'Could not update saved status.')
    },

    onSettled: (_data, _err, id) => {
      void qc.invalidateQueries({ queryKey: ART_KEYS.byId(id) })
    },
  })
}

// ── Flag (moderation) ─────────────────────────────────────────────────────────

export function useFlagArtwork() {
  const qc = useQueryClient()
  const { success, error } = useToast()

  return useMutation({
    mutationFn: ({
      id,
      notes,
      moderationStatus,
    }: {
      id: string
      notes: string
      moderationStatus: 'APPROVED' | 'REJECTED' | 'FLAGGED'
    }) => artworkService.flag(id, notes, moderationStatus),

    onSuccess: ({ data }) => {
      qc.setQueryData(ART_KEYS.byId(data.id), data)
      qc.invalidateQueries({ queryKey: ART_KEYS.lists() })
      success('Moderation saved', 'The artwork moderation status has been updated.')
    },

    onError: () => {
      error('Moderation failed', 'Could not update moderation status.')
    },
  })
}

export function useReportArtwork() {
  const { success, error } = useToast()
  return useMutation({
    mutationFn: ({ id, reason, notes }: { id: string; reason: string; notes?: string }) =>
      artworkService.report(id, reason, notes),
    onSuccess: () => success('Reported', "Thanks — we'll take a look."),
    onError: () => error('Report failed', 'Could not submit your report. Please try again.'),
  })
}

// ── Re-export query key map for external cache invalidation ───────────────────
export { ART_KEYS }