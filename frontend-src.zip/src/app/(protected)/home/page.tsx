'use client'

import { useCallback, useEffect, useMemo, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Spinner } from '@/components'
import Footer from '@/components/layout/footer'
import { Navbar } from '@/components/layout/navbar'
import { HeroSection } from '@/features/home/components/hero'
import { FeedSection } from '@/features/home/components/feed-section'
import { FeedContinuation } from '@/features/home/components/feed-continuation'
import { CreatorCTASection } from '@/features/home/components/creator-cta-section'
import { GalleryPulseSection } from '@/features/home/components/gallery-pulse-section'
import { MobileFilterDrawer } from '@/features/home/components/mobile-filter-drawer'
import { useAuthStore } from '@/store'
import FilterComponent, { FilterDropdownConfig } from '@/features/home/components/filter'
import { DropdownOption } from '@/components/ui/dropdown'
import { INTERESTS } from '@/features/onboarding/data/interests'
import { COLOR_SWATCHES, findClosestSwatch } from '@/features/home/data/color-swatches'
import { useFeed } from '@/hooks/use-artwork'
import type { FeedSort } from '@/features/home/types'
import { useOpenArtwork } from '@/hooks/use-artwork-viewer'
import type { Artwork } from '@/types/artwork'
import { useCountryOptions } from '@/hooks/use-location-data'

const MAX_CATEGORIES = 5

const CATEGORY_OPTIONS: DropdownOption[] = [...INTERESTS]
  .sort((a, b) => a.label.localeCompare(b.label))
  .map((item) => ({ id: item.id, label: item.label }))

const COLOR_OPTIONS: DropdownOption[] = COLOR_SWATCHES.map((c) => ({
  id: c.id,
  label: c.label,
  hex: c.hex,
}))

function HomePage() {
  const isHydrated = useAuthStore((s) => s.isHydrated)

  const [activeTab, setActiveTab] = useState<FeedSort>('for_you')
  const [selectedCategories, setSelectedCategories] = useState<DropdownOption[]>([])
  const [selectedCountry, setSelectedCountry] = useState<DropdownOption | null>(null)
  const [selectedColor, setSelectedColor] = useState<DropdownOption | null>(null)
  const [hexQuery, setHexQuery] = useState('')
  const [countryQuery, setCountryQuery] = useState('')
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false)
  const openArtwork = useOpenArtwork()

  const { countries, isLoading: isLoadingCountries } = useCountryOptions()

  const router = useRouter()
  const searchParams = useSearchParams()
  const query = searchParams.get('q') ?? ''
  const isSearchMode = query.trim().length > 0

  const handleSearch = useCallback(
    (next: string) => {
      const trimmed = next.trim()
      router.push(trimmed ? `/search?q=${encodeURIComponent(trimmed)}` : '/shop')
    },
    [router]
  )

  const countryOptions = useMemo(() => {
    const all: DropdownOption[] = countries.map((c) => ({ id: c.code, label: c.name }))
    if (!countryQuery.trim()) return all
    const q = countryQuery.trim().toLowerCase()
    return all.filter((c) => c.label.toLowerCase().includes(q))
  }, [countries, countryQuery])

  const feedQuery = useFeed({
    sort: activeTab,
    categories: selectedCategories.map((c) => String(c.id)),
    // Homepage feed is portfolio work only — for-sale pieces live in the Artsony Shop section
    listingType: 'PORTFOLIO',
    ...(selectedCountry ? { country: String(selectedCountry.id) } : {})
  })

  // Server-side filter above does the real work; this guards against any listing type slipping through
  const allArtworks = (feedQuery.data?.pages.flatMap((p) => p.data) ?? []).filter(
    (a) => a.listing_type !== 'MARKETPLACE'
  )
  const midpoint = Math.ceil(allArtworks.length / 2)
  const firstHalf = allArtworks.slice(0, midpoint)
  const secondHalf = allArtworks.slice(midpoint)

  const handleArtworkClick = (artwork: Artwork) =>
    openArtwork(artwork, { siblings: allArtworks, variant: 'home' })

  const handleClearFilters = () => {
    setSelectedCategories([])
    setSelectedCountry(null)
    setSelectedColor(null)
    setCountryQuery('')
    setHexQuery('')
  }

  const filterDropdowns: FilterDropdownConfig[] = [
    {
      id: 'category',
      options: CATEGORY_OPTIONS,
      title: 'category',
      multiple: true,
      values: selectedCategories,
      onChangeMultiple: setSelectedCategories,
      maxSelected: MAX_CATEGORIES,
      indicator: 'checkmark',
      placeholder: 'Categories',
      leftIcon: '/icons/widget.svg',
    },
    {
      id: 'color',
      title: 'colour',
      options: COLOR_OPTIONS,
      value: selectedColor,
      onChange: setSelectedColor,
      layout: 'grid',
      searchable: true,
      searchPlaceholder: 'Color',
      searchValue: hexQuery,
      searchVariant: 'button',
      onSearchChange: setHexQuery,
      onSearchSubmit: () => {
        const closest = findClosestSwatch(hexQuery)
        if (closest) setSelectedColor({ id: closest.id, label: closest.label, hex: closest.hex })
      },
      placeholder: 'Color',
      leftIcon: '/icons/palette.svg',
    },
    {
      id: 'location',
      options: countryOptions,
      value: selectedCountry,
      onChange: (opt) => {
        setSelectedCountry(opt)
      },
      indicator: 'checkmark',
      searchable: true,
      searchPlaceholder: 'Search country',
      searchValue: countryQuery,
      onSearchChange: setCountryQuery,
      isLoading: isLoadingCountries,
      emptyMessage: 'No matching countries',
      placeholder: 'Location',
      leftIcon: '/icons/map-point.svg',
    }
  ]

  if (!isHydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white max-md:pb-20">
      <Navbar />
      <HeroSection />
      <div className='max-lg:hidden'>
        <GalleryPulseSection />
      </div>

      <FilterComponent dropdowns={filterDropdowns} onClear={handleClearFilters} />

      <FeedSection
        query={query}
        onSearch={handleSearch}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        artworks={firstHalf}
        isLoading={feedQuery.isLoading}
        onOpenMobileFilters={() => setIsMobileFiltersOpen(true)}
        onArtworkClick={handleArtworkClick}
      />

      <CreatorCTASection />

      <FeedContinuation
        artworks={secondHalf}
        isLoading={feedQuery.isLoading}
        hasNextPage={feedQuery.hasNextPage}
        isFetchingNextPage={feedQuery.isFetchingNextPage}
        onLoadMore={() => feedQuery.fetchNextPage()}
        onArtworkClick={handleArtworkClick}
      />

      <Footer />

      <MobileFilterDrawer
        open={isMobileFiltersOpen}
        onClose={() => setIsMobileFiltersOpen(false)}
        dropdowns={filterDropdowns}
        onClear={handleClearFilters}
        filterNum={allArtworks.length}
      />
    </div>
  )
}

export default function Page() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-white">
          <Spinner size="lg" />
        </div>
      }
    >
      <HomePage />
    </Suspense>
  )
}