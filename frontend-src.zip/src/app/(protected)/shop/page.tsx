'use client'

import { useCallback, useMemo, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Loader2 } from 'lucide-react'
import { Navbar } from '@/components/layout/navbar'
import AroundTheWorld from '@/features/shop/components/around-the-world'
import ArtGrid from '@/features/shop/components/art-grid'
// import { HeroSection } from '@/features/shop/components/hero-section'
import { HeroSection } from '@/features/home/components/hero'
import { SearchSection, ShopFilterState, EMPTY_SHOP_FILTERS } from '@/features/shop/components/search-section'
import TopArt from '@/features/shop/components/top-arts'
import TopPicks from '@/features/shop/components/top-picks'
import { useInfiniteArtworkResults } from '@/hooks/use-artwork'
import type { ArtworkFilters } from '@/types/artwork'
import { useOpenArtwork } from '@/hooks/use-artwork-viewer'
import { ShopResultsGrid } from '@/features/shop/components/shop-result-grid'
import Footer from '@/components/layout/footer'

function toArtworkFilters(query: string, filters: ShopFilterState): ArtworkFilters {
  return {
    listing_type: 'MARKETPLACE',
    status: 'PUBLISHED',
    visibility: 'PUBLIC',
    search: query || undefined,
    categories: filters.category ? [filters.category] : undefined,
    min_price: filters.minPrice ?? undefined,
    max_price: filters.maxPrice ?? undefined,
    artwork_format: filters.format ?? undefined,
    country: filters.country ?? undefined,
    state: filters.state ?? undefined,
    city: filters.city ?? undefined,
  }
}

function ShopContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const query = searchParams.get('q') ?? ''
  const isSearchMode = query.trim().length > 0

  const [filters, setFilters] = useState<ShopFilterState>(EMPTY_SHOP_FILTERS)

  const handleSearch = useCallback(
    (next: string) => {
      const trimmed = next.trim()
      router.push(trimmed ? `/shop?q=${encodeURIComponent(trimmed)}` : '/shop')
    },
    [router]
  )

  const handleFilterChange = useCallback((patch: Partial<ShopFilterState>) => {
    setFilters((prev) => ({ ...prev, ...patch }))
  }, [])

  const handleClearFilters = useCallback(() => {
    setFilters(EMPTY_SHOP_FILTERS)
  }, [])

  const artworkFilters = useMemo(() => toArtworkFilters(query, filters), [query, filters])

  const {
    data,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
  } = useInfiniteArtworkResults(artworkFilters)

  const artworks = useMemo(() => data?.pages.flatMap((p) => p.data) ?? [], [data])
  const total = data?.pages[0]?.total

  const openArtwork = useOpenArtwork()

  const handleGridClick = (index: number) => {
    const artwork = artworks[index]
    if (artwork) openArtwork(artwork, { siblings: artworks, variant: 'shop' })
  }

  return (
    <div className="bg-white">
      <Navbar />
      <HeroSection />
      <SearchSection
        query={query}
        onSearch={handleSearch}
        filters={filters}
        onFilterChange={handleFilterChange}
        onClearFilters={handleClearFilters}
      />

      {isSearchMode ? (
        <ShopResultsGrid
          artworks={artworks}
          isLoading={isLoading}
          isFetchingNextPage={isFetchingNextPage}
          hasNextPage={Boolean(hasNextPage)}
          fetchNextPage={fetchNextPage}
          query={query}
          total={total}
        />
      ) : (
        <>
          <TopPicks />
          <TopArt />
          <AroundTheWorld />

          <ArtGrid
            artworks={artworks}
            num={0}
            artVariant="shop"
            onCardClick={(_, index) => handleGridClick(index)}
          />

          <div className="flex justify-center pb-16">
            {hasNextPage && (
              <button
                onClick={() => fetchNextPage()}
                disabled={isFetchingNextPage}
                className="flex items-center gap-2 font-poppins text-[14px] text-neutral-500 border border-gray-100 rounded-full px-6 py-3 hover:border-primary-500 hover:text-primary-500 transition-colors disabled:opacity-50"
              >
                {isFetchingNextPage && <Loader2 className="w-4 h-4 animate-spin" />}
                Load more Art
              </button>
            )}
          </div>
        </>
      )}

      <Footer />
    </div>
  )
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-white" />}>
      <ShopContent />
    </Suspense>
  )
}