'use client'

import React, { useState, useRef, useEffect, useMemo } from 'react'
import { MoreHorizontal, Smile, Image as ImageIcon } from 'lucide-react'
import { useMessagingStore } from '@/store/messaging.store'
import { useMessages, useSendMessage, useMarkRead } from '@/hooks/use-messaging'
import { MessageBubble } from './message-bubble'
import { ConversationAvatar } from './conversation-list'
import { getConvDisplayName, getConvAvatar } from '../utils/messaging.utils'
import type { ConversationSummary, MessageWithSender } from '@/types/messaging'

interface ChatThreadProps {
  conversationId: string
  conversation: ConversationSummary | null
  myId: string
  goBack?: () => void;
}

export function ChatThread({ conversationId, conversation, myId, goBack }: ChatThreadProps) {
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const { sendRaw, getTypingUsers } = useMessagingStore()
  const { data: messagesData, fetchNextPage, hasNextPage, isFetchingNextPage } = useMessages(conversationId)
  const { mutate: sendMessage, isPending: isSending } = useSendMessage(conversationId)
  const markRead = useMarkRead()

  const messages: MessageWithSender[] = useMemo(() => {
    if (!messagesData?.pages) return []
    return messagesData.pages.flatMap((p) => p.items).reverse()
  }, [messagesData])

  const typingUsers = getTypingUsers(conversationId)
  const displayName = conversation ? getConvDisplayName(conversation, myId) : ''
  const avatar = conversation ? getConvAvatar(conversation) : null

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  // Mark read when conversation is viewed
  useEffect(() => {
    const lastMsg = messages[messages.length - 1]
    if (lastMsg && !lastMsg.id.startsWith('temp_')) {
      markRead(conversationId, lastMsg.id, myId)
    }
  }, [conversationId, messages, markRead, myId])

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isSending) return
    sendMessage({ body: input.trim() })
    setInput('')
    sendRaw({ event: 'typing:stop', conversation_id: conversationId })
    setIsTyping(false)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)

    if (!isTyping) {
      sendRaw({ event: 'typing:start', conversation_id: conversationId })
      setIsTyping(true)
    }

    if (typingTimerRef.current) clearTimeout(typingTimerRef.current)
    typingTimerRef.current = setTimeout(() => {
      sendRaw({ event: 'typing:stop', conversation_id: conversationId })
      setIsTyping(false)
    }, 2_000)
  }

  return (
    <div className="flex h-full flex-col w-full flex-1">
      {/* Header */}
      <div className='px-4 lg:px-6 pt-6 pb-4 flex items-center justify-between w-full border-b border-gray-50'>
        <div className="flex items-center gap-2">
          <button onClick={goBack} className='lg:hidden'>
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <mask id="path-1-inside-1_10823_1736" fill="white">
                <path d="M0 20C0 8.95431 8.95431 0 20 0C31.0457 0 40 8.95431 40 20C40 31.0457 31.0457 40 20 40C8.95431 40 0 31.0457 0 20Z"/>
              </mask>
              <path d="M0 20M40 20M40 20M0 20M20 0M40 20M20 40M0 20M20 40V38C10.0589 38 2 29.9411 2 20H0H-2C-2 32.1503 7.84974 42 20 42V40ZM40 20H38C38 29.9411 29.9411 38 20 38V40V42C32.1503 42 42 32.1503 42 20H40ZM20 0V2C29.9411 2 38 10.0589 38 20H40H42C42 7.84974 32.1503 -2 20 -2V0ZM20 0V-2C7.84974 -2 -2 7.84974 -2 20H0H2C2 10.0589 10.0589 2 20 2V0Z" fill="#E6E8EB" mask="url(#path-1-inside-1_10823_1736)"/>
              <path fill-rule="evenodd" clip-rule="evenodd" d="M30 20C30 25.5228 25.5228 30 20 30C14.4772 30 10 25.5228 10 20C10 14.4772 14.4772 10 20 10C25.5228 10 30 14.4772 30 20ZM16.9696 16.9696C17.2625 16.6768 17.7374 16.6768 18.0303 16.9696L20 18.9393L21.9696 16.9697C22.2625 16.6768 22.7374 16.6768 23.0303 16.9697C23.3232 17.2626 23.3232 17.7374 23.0303 18.0303L21.0606 20L23.0303 21.9696C23.3232 22.2625 23.3232 22.7374 23.0303 23.0303C22.7374 23.3232 22.2625 23.3232 21.9696 23.0303L20 21.0607L18.0303 23.0303C17.7374 23.3232 17.2625 23.3232 16.9696 23.0303C16.6768 22.7374 16.6768 22.2625 16.9696 21.9697L18.9393 20L16.9696 18.0303C16.6767 17.7374 16.6767 17.2625 16.9696 16.9696Z" fill="#525965"/>
            </svg>
          </button>

          <div className='flex items-center gap-2'>
            <ConversationAvatar name={displayName} avatar={avatar} />
            <div>
              <h2 className="text-body-xs lg:text-body-m font-medium font-poppins text-body lg:text-[#02272F]">{displayName}</h2>
              {typingUsers.length > 0 && (
                <p className="text-body-xxs italic text-body">typing...</p>
              )}
            </div>
          </div>
        </div>

        <button className='border border-gray-50 rounded-2xl items-center justify-center p-0.5'>
          <MoreHorizontal className='lg:hidden' />
          <svg className='max-lg:hidden' width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 7.28595 22 4.92893 20.5355 3.46447C19.0711 2 16.714 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447ZM12 13C12.5523 13 13 12.5523 13 12C13 11.4477 12.5523 11 12 11C11.4477 11 11 11.4477 11 12C11 12.5523 11.4477 13 12 13ZM9 12C9 12.5523 8.55228 13 8 13C7.44772 13 7 12.5523 7 12C7 11.4477 7.44772 11 8 11C8.55228 11 9 11.4477 9 12ZM16 13C16.5523 13 17 12.5523 17 12C17 11.4477 16.5523 11 16 11C15.4477 11 15 11.4477 15 12C15 12.5523 15.4477 13 16 13Z" fill="#525965"/>
          </svg>
        </button>
      </div>


      {/* Load older messages */}
      {hasNextPage && (
        <div className="flex justify-center py-2">
          <button
            onClick={() => fetchNextPage()}
            disabled={isFetchingNextPage}
            className="text-[12px] text-primary-500 hover:underline disabled:opacity-50"
          >
            {isFetchingNextPage ? 'Loading...' : 'Load older messages'}
          </button>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 space-y-3 overflow-y-auto px-6 py-4">
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            isMe={msg.sender_id === myId || msg.sender_id === '__me__'}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <footer className="shrink-0 border-t border-gray-100 px-4 py-3">
        <form
          onSubmit={handleSend}
          className="flex items-center gap-3 rounded-full border border-gray-100 bg-white px-4 py-2.5 shadow-sm"
        >
          <button type="button" className="shrink-0 text-gray-400 hover:text-gray-600">
            <Smile size={20} />
          </button>
          <input
            value={input}
            onChange={handleInputChange}
            placeholder="Message"
            className="flex-1 bg-transparent text-[14px] text-gray-700 outline-none placeholder:text-gray-400"
          />
          <button type="button" className="shrink-0 text-gray-400 hover:text-gray-600">
            <ImageIcon size={20} />
          </button>
          {input.trim() && (
            <button
              type="submit"
              disabled={isSending}
              className="shrink-0 rounded-full bg-primary-500 px-4 py-1.5 text-[13px] font-semibold text-white hover:bg-primary-600 disabled:opacity-50"
            >
              Send
            </button>
          )}
        </form>
      </footer>
    </div>
  )
}