"use client";

import * as React from "react";
import Image from "next/image";
import { CircleHelp, X, Upload, FileImage, Video, FileText, File } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components";
import { useArtworkStore } from "@/store/artwork.store";
import { artworkService } from "@/services/artwork.service";
import { useToast } from "@/components/ui/toaster";
import { MEDIA_RULES, mediaKindForFile, validateMediaFile } from "@/lib/media-rules";
import type { ArtworkMediaType } from "@/types/artwork";

// ── Props ─────────────────────────────────────────────────────────────────────

interface UploadArtworkFilesProps {
  id?: string;
  number: string;
  steps?: string;
  onNext: () => void;
  handleBackStep: () => void;
  onSaveAndExit: () => void;
}

// ── Constants ─────────────────────────────────────────────────────────────────

const ACCEPTED_EXTENSIONS = Object.values(MEDIA_RULES)
  .flatMap((rule) => rule.extensions)
  .map((ext) => `.${ext}`)
  .join(",")

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatFileSize(bytes: number): string {
  const mb = bytes / (1024 * 1024)
  return `${mb.toFixed(1).replace(".0", "")}mb`
}

function FileIcon({ mediaType }: { mediaType: ArtworkMediaType }) {
  const cls = "h-5 w-5 text-slate-600"
  if (mediaType === "IMAGE")   return <FileImage className={cls} />
  if (mediaType === "VIDEO")   return <Video className={cls} />
  if (mediaType === "THREE_D") return <FileText className={cls} />
  return <File className={cls} />
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function UploadArtworkFiles({
  number,
  steps = "7",
  onNext,
  handleBackStep,
  onSaveAndExit,
}: UploadArtworkFilesProps) {
  const fileInputRef = React.useRef<HTMLInputElement>(null)
  const uploadingRef = React.useRef(false)
  const abortRef     = React.useRef<AbortController | null>(null)
  const { error: toastError } = useToast()
  const [uploading, setUploading] = React.useState(false)
  const [progress, setProgress]   = React.useState<{ index: number; total: number; percent: number } | null>(null)

  // Leaving the step mid-upload cancels what is still in flight
  React.useEffect(() => () => abortRef.current?.abort(), [])

  const draft          = useArtworkStore((s) => s.draft)
  const addDraftAsset  = useArtworkStore((s) => s.addDraftAsset)
  const removeDraftAsset = useArtworkStore((s) => s.removeDraftAsset)
  const setDraftStep   = useArtworkStore((s) => s.setDraftStep)

  // The file list is read straight from the store: only assets flagged `is_file`
  // (added in this step) show up here, and the gallery on the left skips them.
  // `index` is the asset's real position in draft.assets, used for removal.
  const files = React.useMemo(
    () =>
      (draft.assets ?? []).flatMap((asset, index) =>
        asset.is_file
          ? [{
              index,
              key:       `${asset.original_url}#${index}`,
              name:      asset.file_name ?? asset.mime_type,
              sizeLabel: formatFileSize(asset.file_size_bytes),
              extension: (asset.file_name?.split(".").pop() ?? asset.mime_type.split("/")[1] ?? "FILE").toUpperCase(),
              mediaType: asset.media_type,
            }]
          : [],
      ),
    [draft.assets],
  )

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files ?? [])
    // Reset right away: the FileList is live and the same file can be picked again
    e.target.value = ""
    if (selected.length === 0 || uploadingRef.current) return

    uploadingRef.current = true
    setUploading(true)
    const controller = new AbortController()
    abortRef.current = controller

    try {
      for (const [index, file] of selected.entries()) {
        const mediaType = mediaKindForFile(file)
        if (!mediaType) {
          toastError("Unsupported file", `${file.name} is not a supported file type.`)
          continue
        }

        const invalid = validateMediaFile(file, mediaType)
        if (invalid) {
          toastError(file.name, invalid)
          continue
        }

        try {
          const asset = await artworkService.uploadAsset(file, mediaType, {
            signal: controller.signal,
            onProgress: (percent: any) => setProgress({ index, total: selected.length, percent }),
          })

          addDraftAsset({
            original_url:    asset.original_url,
            optimized_url:   asset.optimized_url,
            thumbnail_url:   asset.thumbnail_url,
            media_type:      mediaType,
            width:           asset.width,
            height:          asset.height,
            duration_secs:   asset.duration_secs,
            mime_type:       asset.mime_type,
            file_size_bytes: asset.file_size_bytes,
            // The store re-numbers ordering_index when it appends
            ordering_index:  0,
            // Client-only: keeps this out of the left-hand gallery
            is_file:         true,
            file_name:       file.name,
          })
        } catch (err) {
          if (err instanceof DOMException && err.name === "AbortError") return
          toastError(
            "Upload failed",
            err instanceof Error ? `${file.name}: ${err.message}` : `${file.name} could not be uploaded.`,
          )
        }
      }
    } finally {
      uploadingRef.current = false
      abortRef.current = null
      setUploading(false)
      setProgress(null)
    }
  }

  const handleNextStep = () => {
    setDraftStep(4)
    onNext()
  }

  return (
    <div className="flex h-full w-full max-w-2xl flex-col bg-white border border-neutral-100 rounded-[40px] overflow-hidden font-poppins">

      {/* HEADER */}
      <div className="flex justify-between px-6 py-4 items-center border-b border-gray-50">
        <div className="flex gap-4 items-center">
          <h6 className="font-raleway font-semibold text-primary-500 text-h5 leading-8 tracking-wide">Step</h6>
          <h6 className="font-raleway font-semibold text-primary-500 text-h5 leading-8 tracking-wide">
            {number ?? "3"}<span className="text-gray-500">/{steps}</span>
          </h6>
        </div>
        <div className="flex gap-4 items-center">
          <Button variant="outline" className="py-3 px-6 leading-6 text-sm font-medium" onClick={onSaveAndExit}>
            Save Draft
          </Button>
          <button type="button" onClick={onSaveAndExit} className="border border-gray-50 rounded-full p-2 hover:bg-gray-50 transition-colors">
            <Image src="/icons/cancel.svg" width={20} height={20} alt="cancel icon" />
          </button>
        </div>
      </div>

      {/* CONTENT */}
      <div className="min-h-0 flex-1 p-6 space-y-6 overflow-y-auto custom-scrollbar">

        {/* HEADING */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <label className="text-[18px] font-semibold text-neutral-800">
              <span className="text-[#F15A2B] mr-1">*</span>Upload Artwork Files
            </label>
            <CircleHelp size={18} className="text-[#30A2FF]" fill="#30A2FF" color="white" />
          </div>
          <p className="text-sm leading-relaxed text-neutral-400 font-medium">
            Upload all relevant files in high quality. Supported formats: JPG, PNG, TIFF (up to 50MB),
            MP4, MOV, AVI or MKV (up to 500MB), GLTF / GLB / OBJ / FBX (up to 500MB).
          </p>
        </div>

        {/* UPLOAD TRIGGER */}
        <div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            multiple
            accept={ACCEPTED_EXTENSIONS}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            aria-busy={uploading}
            className="w-full h-16 rounded-full border border-dashed border-neutral-200 bg-white hover:border-[#F15A2B] transition-all flex items-center justify-center gap-2.5 group disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Upload size={18} className="text-[#F15A2B] transition-transform group-hover:-translate-y-0.5" />
            <span className="text-sm font-semibold text-[#F15A2B]">
              {progress
                ? `Uploading${progress.total > 1 ? ` ${progress.index + 1} of ${progress.total}` : ""}… ${progress.percent}%`
                : uploading ? "Uploading…" : "Upload File"}
            </span>
          </button>
        </div>

        {/* FILE LIST */}
        <AnimatePresence>
          {files.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="border border-neutral-100 rounded-[32px] p-2 bg-white overflow-hidden"
            >
              <div className="max-h-[290px] overflow-y-auto custom-scrollbar divide-y divide-neutral-50 px-4">
                {files.map((file) => (
                  <motion.div
                    key={file.key}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="flex items-center justify-between py-4"
                  >
                    {/* Left — icon + name */}
                    <div className="flex items-center gap-3.5 max-w-[75%] overflow-hidden">
                      <div className="h-10 w-10 flex items-center justify-center rounded-full bg-slate-100/80 shrink-0">
                        <FileIcon mediaType={file.mediaType} />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="text-sm font-medium text-neutral-700 truncate pr-2">
                          {file.name}
                        </span>
                        <span className="text-xs text-neutral-400 uppercase tracking-wider">
                          {file.mediaType}
                        </span>
                      </div>
                    </div>

                    {/* Right — size + remove */}
                    <div className="flex items-center gap-4 shrink-0">
                      <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                        {file.sizeLabel} · {file.extension}
                      </span>
                      <button
                        type="button"
                        aria-label={`Remove ${file.name}`}
                        onClick={() => removeDraftAsset(file.index)}
                        className="h-8 w-8 flex items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:bg-neutral-200 hover:text-neutral-700 transition-colors"
                      >
                        <X size={15} strokeWidth={2.5} />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* FOOTER */}
      <div className="py-6 px-6 flex gap-4 border-t border-gray-50 bg-white sticky bottom-0">
        <Button
          variant="outline"
          fullWidth
          onClick={handleBackStep}
          className="rounded-full py-4 border-primary-500 text-primary-500 flex items-center justify-center gap-2 hover:bg-primary-50"
        >
          <Image src="/icons/alt-arrow-left-double-red.svg" width={18} height={18} alt="back icon" />
          Back
        </Button>
        <Button
          fullWidth
          onClick={handleNextStep}
          disabled={uploading}
          className="rounded-full py-4 bg-primary-500 text-white flex items-center justify-center gap-2 hover:bg-primary-600 shadow-lg shadow-primary-500/20"
        >
          Next
          <Image src="/icons/alt-arrow-right-double.svg" width={18} height={18} alt="next icon" />
        </Button>
      </div>
    </div>
  )
}