'use client'

import { useCallback, useRef, useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Loader2 } from 'lucide-react'
import { motion } from 'framer-motion'
import { ArtCard } from '@/components/ui/art-card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQuickAddToCart } from '@/hooks/use-cart-actions'
import type { Artwork } from '@/types'
import EmptySearch from './empty-search'
import { Dropdown, DropdownOption } from '@/components/ui/dropdown'
import { FEED_TABS, FeedSort } from '@/features/home/types'

// ─── ResultsGrid ──────────────────────────────────────────────────────────────

type ResultsGridProps = {
  artworks: Artwork[]
  isLoading: boolean
  isFetchingNextPage: boolean
  hasNextPage: boolean
  fetchNextPage: () => void
  query: string
  total?: number
  onArtworkClick: (artwork: Artwork) => void
}

const FEED_TAB_OPTIONS: DropdownOption[] = FEED_TABS.map((t) => ({ id: t.value, label: t.label }))

export function ResultsGrid({
  artworks,
  isLoading,
  isFetchingNextPage,
  hasNextPage,
  fetchNextPage,
  query,
  total,
  onArtworkClick,
}: ResultsGridProps) {
  const observerRef = useRef<IntersectionObserver | null>(null)
  const { quickAdd } = useQuickAddToCart()

  const sentinelRef = useCallback(
    (node: HTMLDivElement | null) => {
      if (observerRef.current) observerRef.current.disconnect()
      if (!node) return
      observerRef.current = new IntersectionObserver(
        ([entry]) => {
          if (entry?.isIntersecting && hasNextPage && !isFetchingNextPage) fetchNextPage()
        },
        { rootMargin: '200px' }
      )
      observerRef.current.observe(node)
    },
    [fetchNextPage, hasNextPage, isFetchingNextPage]
  )
  const [activeTab, setActiveTab] = useState<FeedSort>('for_you')
  
  const activeOption = FEED_TAB_OPTIONS.find((o) => o.id === activeTab) ?? FEED_TAB_OPTIONS[0]


  if (isLoading) {
    return (
      <div className="mx-auto px-4 md:px-8 py-8">
        <Skeleton className="h-5 w-48 mb-6 rounded-full" />
        <ResultsSkeleton />
      </div>
    )
  }

  if (artworks.length === 0) {
    return <EmptySearch />
  }

  return (
    <div className="px-4 md:px-8 py-6">

      <div className='flex items-center justify-between mb-6'>
        {/* Result count */} 
        {total !== undefined && (
          <p className="font-raleway font-semibold text-h6 lg:text-h5 text-body">
            <span className="font-semibold text-primary-600">{total.toLocaleString()}</span>{' '}
              Result{total !== 1 ? 's' : ''} <span className='max-md:hidden'>For {query}</span>
          </p>
        )}

      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10">
        {artworks.map((artwork, i) => (
          <motion.div
            key={artwork.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(i * 0.04, 0.32), duration: 0.4 }}
            className="flex justify-center"
          >
            <ArtCard
              image={artwork.assets[0]?.thumbnail_url || artwork.assets[0]?.optimized_url || artwork.assets[0]?.original_url as string}
              title={artwork.title}
              onCardClick={() => onArtworkClick(artwork)}
              showCart={artwork.listing_type === 'MARKETPLACE'}
              showVideo={artwork.assets[0]?.media_type === 'VIDEO'}
              onAction={(action) => {
                if (action === 'cart') quickAdd(artwork)
              }}
              artist={[{
                id: artwork.creator_id,
                name: artwork.creator?.username as string,
                avatar_url: artwork.creator?.profile?.avatar_url ?? '/images/image-avatar.svg',
              }]}
              stats={{
                likes: String(artwork.like_count),
                views: String(artwork.view_count),
              }}
              variant="standard"
            />
          </motion.div>
        ))}
      </div>

      {/* Infinite scroll sentinel */}
      <div ref={sentinelRef} className="h-4 mt-4" />

      {isFetchingNextPage && (
        <div className="flex justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-primary-500" />
        </div>
      )}

      {!hasNextPage && artworks.length > 0 && (
        <p className="text-center font-poppins text-[12px] text-neutral-300 pt-8">
          All results loaded
        </p>
      )}
    </div>
  )
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function ResultsSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="flex flex-col gap-x-4 max-w-[332px] mx-auto w-full">
          <Skeleton className="w-full aspect-[364/332] rounded-[40px]" />
          <Skeleton className="w-full h-[55px] rounded-full" />
        </div>
      ))}
    </div>
  )
}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState({ query }: { query: string }) {
  return (
    <div className="flex flex-col items-center gap-4 py-24 text-center px-4">
      <div className="w-16 h-16 rounded-full bg-neutral-50 flex items-center justify-center">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
          <circle cx="12" cy="12" r="8" stroke="#D2D5DA" strokeWidth="2" />
          <path d="M18 18L24 24" stroke="#D2D5DA" strokeWidth="2" strokeLinecap="round" />
          <path d="M9 12h6M12 9v6" stroke="#D2D5DA" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <div>
        <p className="font-raleway font-semibold text-[18px] text-neutral-600">
          No results for "{query}"
        </p>
        <p className="font-poppins text-[13px] text-neutral-400 mt-1 max-w-xs mx-auto leading-5">
          Try different keywords or remove some filters.
        </p>
      </div>
      <Link
        href="/discover"
        className="font-poppins text-[13px] font-medium text-primary-500 hover:text-primary-600 underline underline-offset-2 transition-colors"
      >
        Browse all artwork instead
      </Link>
    </div>
  )
}