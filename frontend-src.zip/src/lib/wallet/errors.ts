import { HttpError } from '@/lib/api-client'

// The API reports what was wrong per field (minimum amount, address format,
// insufficient balance); show that rather than a generic "Validation failed".
export function withdrawalErrorMessage(err: unknown): string {
  if (err instanceof HttpError && err.fields && !Array.isArray(err.fields)) {
    const details = Object.values(err.fields).filter(Boolean)
    if (details.length > 0) return details.join(' ')
  }
  return err instanceof Error ? err.message : 'Could not process your withdrawal.'
}
