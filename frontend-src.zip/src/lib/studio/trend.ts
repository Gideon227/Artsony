import type { TrendDirection } from '@/types/wallet'

export function formatTrendPercent(changePercent: number): string {
  return `${Number(Math.abs(changePercent).toFixed(2))}%`
}

export const TREND_LABEL: Record<TrendDirection, string> = {
  UP: 'Up',
  DOWN: 'Down',
  FLAT: 'No change',
}

export const TREND_TEXT_CLASS: Record<TrendDirection, string> = {
  UP: 'text-successful-600',
  DOWN: 'text-error-600',
  FLAT: 'text-body',
}
